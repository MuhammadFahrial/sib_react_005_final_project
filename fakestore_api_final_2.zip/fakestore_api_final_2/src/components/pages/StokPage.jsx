import React from "react";

const StokPage = () => {
  return (
    <div>
      <h1>StokPage</h1>
    </div>
  );
};

export default StokPage;
