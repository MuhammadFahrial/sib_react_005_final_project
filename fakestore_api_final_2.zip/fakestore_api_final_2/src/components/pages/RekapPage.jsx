import React from "react";

const RekapPage = () => {
  return (
    <div>
      <h1>RekapPage</h1>
    </div>
  );
};

export default RekapPage;
