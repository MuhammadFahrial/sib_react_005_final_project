Kelompok - 3

A. MUH. FAHRIAL S           - RCTN-KS05-012 > lead
WAHYU ALIF DHARMAWAN        - RCTN-KS05-014
ELLA BUDI WIJAYANTI         - RCTN-KS05-005

Link Panduan : https://docs.google.com/document/d/14GAYxMKZY7HODFRe2uVUftWRvZ8hEz9wTAGOXkQza6I/edit
Job Desk : https://www.notion.so/FInal-Project-2-286bb687665c42aa9c8c9765a857dd8a
UI Figma : https://www.figma.com/file/zbQBPZvJLCOzOx7v4MHUoF/Final-Project-2?node-id=0%3A1

User Login : 
username : user@login.com
password : user

Admin Login :
username : admin@login.com
password : admin123

1. Coding 
2. Desain
3. Database localStorage(redux)
4. Panduan 
5. Presentasi berdasar apa yang dikerjakan masing-masing
6. Crosscheck penggunaan Github
7. Hasil